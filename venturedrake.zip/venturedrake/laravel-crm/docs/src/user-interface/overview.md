# Overview

Use the Laravel CRM with a complete user interface you can use instantly.

## Accessing the user interface

Once installed, just head to http://<yoursite>/crm and you should see the login screen.

