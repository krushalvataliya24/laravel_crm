<div class="row">
    <div class="col-sm-6 border-right">
       ...
    </div>
    <div class="col-sm-6">
        ...
    </div>
</div>