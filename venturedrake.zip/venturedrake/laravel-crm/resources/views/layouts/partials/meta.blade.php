<meta name="date_format" content="{{ $dateFormat }}" />
<meta name="time_format" content="{{ $timeFormat }}" />
<meta name="dynamic_products" content="{{ $dynamicProducts }}" />