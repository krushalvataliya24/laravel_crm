@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::deals.partials.card-create')

@endsection