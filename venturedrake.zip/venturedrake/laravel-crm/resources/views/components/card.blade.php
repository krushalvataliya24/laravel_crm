<div class="card mb-4">
    {{ $slot }}
</div>