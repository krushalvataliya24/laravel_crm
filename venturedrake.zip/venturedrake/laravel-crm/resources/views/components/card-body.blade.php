<div class="card-body">
    {{ $slot }}
</div>