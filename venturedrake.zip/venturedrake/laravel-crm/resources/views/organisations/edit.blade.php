@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::organisations.partials.card-edit')
    
@endsection