@extends('laravel-crm::layouts.app')

@section('content')

    @include('laravel-crm::invoices.partials.card-edit')

@endsection
