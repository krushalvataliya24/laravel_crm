@extends('laravel-crm::layouts.app')

@section('content')

   @include('laravel-crm::people.partials.card-index')
    
@endsection